# mathmod-124-17
## Вариант 124-17
- Задание 1 - [Манипуляции с данными](https://github.com/andthefox/mathmod-124-17/tree/master/assignment_1)
- Задание 2 - [Множественная регрессия](https://github.com/andthefox/mathmod-124-17/tree/master/assignment_2)
- Задание 3 - [...](https://github.com/andthefox/mathmod-124-17/tree/master/assignment_3)
